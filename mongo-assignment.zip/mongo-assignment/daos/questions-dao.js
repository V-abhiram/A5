const questionsModel = require('../models/questions/questions-model.js')
const findQuestionById = (qid) => questionsModel.findById(qid)
const findQuestionsForQuiz = (qzid) => questionsModel.find({quizId: qzid})
const findAllQuestions = () => questionsModel.find()
module.exports = {findQuestionById, findQuestionsForQuiz, findAllQuestions}